<mxfile host="app.diagrams.net">
  <diagram name="STRIDE Threat Model">
    <mxGraphModel dx="1400" dy="800" grid="1" gridSize="10">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>

        <!-- Customers -->
        <mxCell id="cust" value="Customers" style="ellipse;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
          <mxGeometry x="40" y="250" width="140" height="60" as="geometry"/>
        </mxCell>

        <!-- Company Portal -->
        <mxCell id="portal" value="Company Portal&#xa;- Spoofing&#xa;- Tampering&#xa;- DoS&#xa;- Info Disclosure" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
          <mxGeometry x="260" y="120" width="220" height="120" as="geometry"/>
        </mxCell>

        <!-- Managers -->
        <mxCell id="mgr" value="Managers&#xa;- Spoofing&#xa;- Repudiation&#xa;- Elevation of Privilege" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
          <mxGeometry x="540" y="230" width="180" height="100" as="geometry"/>
        </mxCell>

        <!-- Event Networkers -->
        <mxCell id="event" value="Event Networkers&#xa;- Spoofing&#xa;- Tampering" style="ellipse;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="1">
          <mxGeometry x="260" y="360" width="200" height="90" as="geometry"/>
        </mxCell>

        <!-- Delivery Team -->
        <mxCell id="delivery" value="Delivery Team&#xa;- Repudiation&#xa;- Elevation of Privilege" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
          <mxGeometry x="820" y="240" width="200" height="90" as="geometry"/>
        </mxCell>

        <!-- Product Development -->
        <mxCell id="prod" value="Product Development&#xa;- Information Disclosure&#xa;- Tampering" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
          <mxGeometry x="540" y="420" width="260" height="100" as="geometry"/>
        </mxCell>

        <!-- Edges -->
        <mxCell id="e1" style="endArrow=block;html=1;" edge="1" parent="1" source="cust" target="portal">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e2" style="endArrow=block;html=1;" edge="1" parent="1" source="cust" target="mgr">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e3" style="endArrow=block;html=1;" edge="1" parent="1" source="event" target="mgr">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e4" style="endArrow=block;html=1;" edge="1" parent="1" source="mgr" target="delivery">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e5" style="endArrow=block;html=1;" edge="1" parent="1" source="mgr" target="prod">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
