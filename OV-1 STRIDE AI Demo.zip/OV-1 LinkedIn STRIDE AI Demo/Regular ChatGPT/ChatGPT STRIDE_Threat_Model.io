<mxfile host="app.diagrams.net">
  <diagram name="STRIDE Threat Model">
    <mxGraphModel dx="1420" dy="800" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1600" pageHeight="1200">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>

        <!-- Entities -->
        <mxCell id="customers" value="Customers&#xa;(Web / Email / Phone / Face-to-Face)" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;" vertex="1" parent="1">
          <mxGeometry x="40" y="260" width="180" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="portal" value="Company Portal" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;" vertex="1" parent="1">
          <mxGeometry x="300" y="260" width="160" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="managers" value="Managers" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;" vertex="1" parent="1">
          <mxGeometry x="560" y="260" width="140" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="networkers" value="Event Networkers" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f8cecc;" vertex="1" parent="1">
          <mxGeometry x="560" y="400" width="160" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="delivery" value="Delivery Team" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;" vertex="1" parent="1">
          <mxGeometry x="780" y="260" width="150" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="dev" value="Product Development" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;" vertex="1" parent="1">
          <mxGeometry x="1020" y="260" width="180" height="80" as="geometry"/>
        </mxCell>

        <!-- Edges -->
        <mxCell id="e1" edge="1" parent="1" source="customers" target="portal" value="Web Inquiry">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e2" edge="1" parent="1" source="portal" target="managers" value="Review Inquiry">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e3" edge="1" parent="1" source="networkers" target="managers" value="Report Leads">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e4" edge="1" parent="1" source="managers" target="delivery" value="Assign Team">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e5" edge="1" parent="1" source="delivery" target="dev" value="Product Feedback/Dev">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <!-- STRIDE Notes -->
        <mxCell id="stride1" value="STRIDE (Customers → Portal)&#xa;S: Spoofing&#xa;T: Tampering&#xa;R: Repudiation&#xa;I: Info Disclosure&#xa;D: DoS&#xa;E: Elevation&#xa;Controls: MFA, TLS, WAF, Input validation, Logs" style="whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#000000;" vertex="1" parent="1">
          <mxGeometry x="250" y="120" width="300" height="120" as="geometry"/>
        </mxCell>

        <mxCell id="stride2" value="STRIDE (Portal → Managers)&#xa;Phishing, Privilege abuse, Data exposure&#xa;Controls: SSO+MFA, RBAC, Immutable logs" style="whiteSpace=wrap;html=1;fillColor=#ffffff;" vertex="1" parent="1">
          <mxGeometry x="520" y="120" width="280" height="100" as="geometry"/>
        </mxCell>

        <mxCell id="stride3" value="STRIDE (Managers → Delivery)&#xa;Fake assignments, Task tampering&#xa;Controls: Signed messages, Workflow logs, Approvals" style="whiteSpace=wrap;html=1;fillColor=#ffffff;" vertex="1" parent="1">
          <mxGeometry x="760" y="120" width="280" height="100" as="geometry"/>
        </mxCell>

        <mxCell id="stride4" value="STRIDE (Networkers → Managers)&#xa;Mobile loss, Fake reporters, Lead tampering&#xa;Controls: Auth submissions, MDM, Encryption" style="whiteSpace=wrap;html=1;fillColor=#ffffff;" vertex="1" parent="1">
          <mxGeometry x="520" y="510" width="320" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="stride5" value="STRIDE (Internal → Dev)&#xa;Code tampering, IP leakage, Pipeline attack&#xa;Controls: Code signing, Repo ACLs, mTLS, CI security" style="whiteSpace=wrap;html=1;fillColor=#ffffff;" vertex="1" parent="1">
          <mxGeometry x="980" y="120" width="320" height="110" as="geometry"/>
        </mxCell>

      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
